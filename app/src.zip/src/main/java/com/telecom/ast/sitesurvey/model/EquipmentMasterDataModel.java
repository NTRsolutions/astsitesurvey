package com.telecom.ast.sitesurvey.model;

/**
 * Created by AST on 07/04/2017.
 */

public class EquipmentMasterDataModel {

    String equipId;
    String equipType;
    String equipCode;
    String equipDes;
    String equipMake;
    String equipModel;
    String equipRating;
    String lastUpdatedDate;

    public String getEquipId() {
        return equipId;
    }

    public void setEquipId(String equipId) {
        this.equipId = equipId;
    }

    public String getEquipType() {
        return equipType;
    }

    public void setEquipType(String equipType) {
        this.equipType = equipType;
    }

    public String getEquipCode() {
        return equipCode;
    }

    public void setEquipCode(String equipCode) {
        this.equipCode = equipCode;
    }

    public String getEquipDes() {
        return equipDes;
    }

    public void setEquipDes(String equipDes) {
        this.equipDes = equipDes;
    }

    public String getEquipMake() {
        return equipMake;
    }

    public void setEquipMake(String equipMake) {
        this.equipMake = equipMake;
    }

    public String getEquipModel() {
        return equipModel;
    }

    public void setEquipModel(String equipModel) {
        this.equipModel = equipModel;
    }

    public String getEquipRating() {
        return equipRating;
    }

    public void setEquipRating(String equipRating) {
        this.equipRating = equipRating;
    }

    public String getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(String lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
}
