package com.telecom.ast.sitesurvey.listener;

public interface AlertDialogBoxClickInterface
{
	void onButtonClicked(boolean isPositiveButtonClicked);
}
