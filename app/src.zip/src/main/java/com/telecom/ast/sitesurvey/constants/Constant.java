package com.telecom.ast.sitesurvey.constants;

/**
 * Created by mohit on 10/12/2015.
 */
public class Constant {

    public static String BASE_URL = "http://54.255.164.25/ASTTelecomWebAPI/api/";

    public static String LOGIN_URL = "User/AuthinticateUser/";
    public static String CIRCLE_MASTER_URL = "Master/CircleMaster";
    public static String SITE_MASTER_URL = "Master/SiteList";
    public static String EQUIPMENT_MASTER_URL = "Master/EquipmentList";

}

