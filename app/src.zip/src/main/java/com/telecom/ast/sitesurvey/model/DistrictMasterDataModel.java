package com.telecom.ast.sitesurvey.model;

/**
 * Created by AST on 20-03-2017.
 */

public class DistrictMasterDataModel {

    String districtId;
    String districtName;
    String circleId;
    String districtLastUpdated;

    public String getDistrictId() {
        return districtId;
    }

    public void setDistrictId(String districtId) {
        this.districtId = districtId;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getCircleId() {
        return circleId;
    }

    public void setCircleId(String circleId) {
        this.circleId = circleId;
    }

    public String getDistrictLastUpdated() {
        return districtLastUpdated;
    }

    public void setDistrictLastUpdated(String districtLastUpdated) {
        this.districtLastUpdated = districtLastUpdated;
    }
}
