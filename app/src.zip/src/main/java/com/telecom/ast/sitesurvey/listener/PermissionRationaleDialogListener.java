package com.telecom.ast.sitesurvey.listener;

public interface PermissionRationaleDialogListener 
{
	void onCancelPermissionRationale(int requestCode);
}
