package com.telecom.ast.sitesurvey.utils;

/**
 * <h4>Created</h4> 02/25/16
 *
 * @author AST Inc.
 */
public class ASTSymbols {

	public static final String TILDE = "~";
	public static final String HIPHEN = "-";
	public static final String COMMA = ",";
	public static final String AT_RATE = "@";
	public static final String UNDERSCORE = "_";
	public static final String COLON = ":";
	public static final String SEMICOLON = ";";
}
